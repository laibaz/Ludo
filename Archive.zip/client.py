from socket import *

serverName = 'localhost'
serverPort = 12000
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect((serverName, serverPort))

while True:
    sentence = input('Please Enter postfix Expression: ')
    clientSocket.send(bytes(sentence, "utf-8"))

    modifiedSentence = clientSocket.recv(1024)
    received = modifiedSentence.decode()
    print('The result from the server:', received)

    another_computation = input("Do you want to perform another computation? (yes/no): ").strip().lower()

    if another_computation != 'yes':
        break

clientSocket.close()
